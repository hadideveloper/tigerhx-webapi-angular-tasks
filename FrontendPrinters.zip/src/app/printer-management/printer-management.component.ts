import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface Printer {
  name: string;
  ip: string;
  isOnline: boolean;
}

@Component({
  selector: 'app-printer-management',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './printer-management.component.html',
  styleUrls: ['./printer-management.component.css']
})
export class PrinterManagementComponent {
  printers: Printer[] = [
    { name: 'Football', ip: '192.168.1.50', isOnline: true },
    { name: 'Cafe', ip: '192.168.1.55', isOnline: false }
  ];

  showModal = false;
  newPrinter: Printer = { name: '', ip: '', isOnline: false };

  openAddPrinterModal() {
    this.showModal = true;
  }

  closeModal() {
    this.showModal = false;
    this.newPrinter = { name: '', ip: '', isOnline: false };
  }

  addPrinter() {
    // ip check
    if (!this.validateIp(this.newPrinter.ip)) {
      alert('Please enter a valid IP address!');
      return;
    }

    // online/offline test (заглушка)
    this.newPrinter.isOnline = Math.random() > 0.5;

    this.printers.push({ ...this.newPrinter });
    this.closeModal();
    alert(`Printer ${this.newPrinter.name} added successfully!`);
  }

  removePrinter(printerToRemove: Printer) {
    if (confirm(`Are you sure you want to delete ${printerToRemove.name}?`)) {
      this.printers = this.printers.filter(printer => printer.ip !== printerToRemove.ip);
      // localStorage - opportunity = this.savePrinters();
      alert(`Printer ${printerToRemove.name} deleted successfully!`);
    }
  }

  private validateIp(ip: string): boolean {
    const pattern = /^([0-9]{1,3}\.){3}[0-9]{1,3}$/;
    return pattern.test(ip);
  }
}
