import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-print-actions',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './print-actions.component.html',
  styles: [`
    .card {
      max-width: 800px;
      margin: 0 auto;
    }
    .form-control {
      margin-bottom: 10px;
    }
  `]
})
export class PrintActionsComponent {
  selectedPrinter: string = '';
  invoiceData = {
    invoiceNumber: '',
    date: new Date().toISOString().split('T')[0],
    customerName: '',
    productDetails: '',
    totalAmount: '',
    extraNotes: ''
  };

  print() {
    if (!this.selectedPrinter) {
      alert('Please select a printer!');
      return;
    }

    console.log('Printing data:', {
      printer: this.selectedPrinter,
      ...this.invoiceData
    });

    alert(`Invoice ${this.invoiceData.invoiceNumber} sent to ${this.selectedPrinter}`);
  }

  preview() {
    alert('soon preview');
  }
}
